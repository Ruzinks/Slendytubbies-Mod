===============================================
    SLENDYTUBBIES MOD - PRE-RELEASE v0.1
           NOCTURNE STUDIOS
===============================================

Desarrollado por: Nocturne Studios
Desarrolladores: Noctis y Ruzinks

-----------------------------------------------

¡Gracias por probar la primera Pre-Release oficial! Este mod introduce a los icónicos personajes de Slendytubbies en el mundo de Minecraft con un enfoque en el terror y la supervivencia extrema.

--- CONTENIDO DE ESTA VERSIÓN ---

* ENTIDADES:
  - Tinky Winky, Dipsy, Laa-Laa y Po han llegado.
  - Comportamientos y estadísticas ajustadas para ofrecer un reto real.

* MECÁNICAS:
  - Sistema de Spawn Natural: La noche ahora es mucho más peligrosa.
  - Nuevo ítem funcional: Tubby Custard.

--- INSTRUCCIONES DE INSTALACIÓN ---
1. Asegúrate de tener instalado NeoForge (Versión 1.21.1).
2. Localiza tu carpeta de juego (.minecraft/mods).
3. Copia el archivo 'slendytubbies.jar' incluido en este paquete y pégalo en la carpeta 'mods'.
4. Inicia el juego. Te recomendamos no salir de noche sin equipamiento.

--- NOTA DE LOS DESARROLLADORES ---
Esta es una versión Pre-Release (Alpha) enfocada en probar el rendimiento y la dificultad base. Todo lo que veas aquí es solo el comienzo de lo que Nocturne Studios tiene preparado.


===============================================
© 2026 NOCTURNE STUDIOS.
===============================================